const { useState: useS3 } = React;

function TopBar({ onToggleTweaks }) {
  return (
    <div className="top-bar">
      <div className="top-bar-left">
        <div className="brand-fixed">
          <div className="brand-logo">ENTER<span className="caret" /></div>
          <div className="brand-logo-sub">OS</div>
        </div>
        <span className="view-title"><strong>Home</strong> · visão do advogado</span>
      </div>
      <div className="top-bar-right">
        <button className="nav-icon-btn" title="Buscar"><Icon name="search" /></button>
        <button className="nav-icon-btn" title="Tweaks" onClick={onToggleTweaks}><Icon name="sliders" /></button>
        <button className="nav-icon-btn" title="Notificações">
          <Icon name="bell" />
          <span className="notification-dot" />
        </button>
        <button className="nav-icon-btn" title="Perfil"><Icon name="user" /></button>
      </div>
    </div>
  );
}

function Sidebar() {
  const [active, setActive] = useS3(1);
  return (
    <div className="global-sidebar">
      <button className="new-case-btn">
        <Icon name="plus" size={14} /> Novo processo
      </button>
      <div className="sidebar-section">
        <div className="section-title">Histórico recente</div>
        {CASES.slice(0, 6).map(c => (
          <div
            key={c.id}
            className={`history-item ${active === c.id ? 'active' : ''}`}
            onClick={() => setActive(c.id)}
            title={c.plaintiff}
          >
            <span className={`risk-dot ${c.risk.toLowerCase() === 'médio' ? 'alto' : c.risk.toLowerCase()}`} />
            <span className="truncate">{c.plaintiff}</span>
          </div>
        ))}
      </div>
      <div className="sidebar-footer">
        <div className="footer-item"><Icon name="dash" size={16} /> Dashboard macro</div>
        <div className="footer-item"><Icon name="db" size={16} /> Base histórica</div>
        <div className="footer-item"><Icon name="shield" size={16} /> Política de acordos</div>
        <div className="footer-item"><Icon name="gear" size={16} /> Configurações</div>
        <div className="user-info">
          <div className="user-avatar">AS</div>
          <div className="user-details">
            <div className="user-name">Advogado Silva</div>
            <div className="user-role">sócio · OAB 98.321</div>
          </div>
          <Icon name="logout" size={14} />
        </div>
      </div>
    </div>
  );
}

function MacroStrip() {
  return (
    <div className="macro-strip">
      {MACRO.map((m, i) => (
        <div className="macro-cell" key={i}>
          <span className="label">{m.label}</span>
          <span className={`value ${m.accent ? 'accent' : ''}`}>{m.value}</span>
          <span className="sub">
            <span className={`trend ${m.trend}`}>{m.trend === 'up' ? '▲' : '▼'}</span>
            {m.sub}
          </span>
        </div>
      ))}
    </div>
  );
}

function CaseTable({ filter, setFilter }) {
  const filtered = filter === 'todos'
    ? CASES
    : CASES.filter(c => c.recommendation.toLowerCase() === filter);
  return (
    <>
      <div className="section-head">
        <div style={{display:'flex', alignItems:'baseline', gap: 14}}>
          <h2>Fila de processos</h2>
          <span className="count">{filtered.length} casos · ordenado por risco</span>
        </div>
        <div style={{display:'flex', gap: 8}}>
          <button className={`filter-pill ${filter === 'todos' ? 'active' : ''}`} onClick={() => setFilter('todos')}>todos</button>
          <button className={`filter-pill ${filter === 'defesa' ? 'active' : ''}`} onClick={() => setFilter('defesa')}>defesa</button>
          <button className={`filter-pill ${filter === 'acordo' ? 'active' : ''}`} onClick={() => setFilter('acordo')}>acordo</button>
        </div>
      </div>

      <div className="case-table">
        <div className="case-row header">
          <span>Parte autora / nº processo</span>
          <span>Valor</span>
          <span>Risco</span>
          <span>Recomendação</span>
          <span></span>
        </div>
        {filtered.map(c => (
          <div className="case-row" key={c.id}>
            <div className="case-primary">
              <span className="case-plaintiff">{c.plaintiff}</span>
              <span className="case-number">{c.number} · {c.received}</span>
            </div>
            <span className="case-value">{c.value}</span>
            <span className={`risk-badge ${c.risk.toLowerCase() === 'médio' ? 'medio' : c.risk.toLowerCase()}`}>
              {c.risk}
            </span>
            <span className={`reco-pill ${c.recommendation.toLowerCase()}`}>
              {c.recommendation}
            </span>
            <button className="open-case-btn">
              Abrir <Icon name="arrow" size={11} />
            </button>
          </div>
        ))}
      </div>
    </>
  );
}

function AgentCard() {
  return (
    <div className="rail-card">
      <div className="rail-card-header">
        <Icon name="bot" size={16} />
        <h3>Agente jurídico</h3>
        <span className="pulse" />
      </div>
      <div className="rail-card-body">
        <div className="agent-msg">
          Bom dia, Silva. Sua fila tem <span className="highlight">6 casos</span> aguardando decisão.
          <br /><br />
          <span className="highlight">3 são de alto risco</span> (fortuito interno provável) — recomendo priorizar o caso
          de <strong>José Raimundo</strong>, onde a política sugere <span className="highlight">acordo ≤ R$ 7.000</span>.
          <br /><br />
          Posso preparar o resumo e a minuta da proposta?
        </div>
      </div>
    </div>
  );
}

function PolicyCard() {
  return (
    <div className="rail-card">
      <div className="rail-card-header">
        <Icon name="shield" size={16} />
        <h3>Política de acordos · v2.1</h3>
      </div>
      <div className="rail-card-body">
        <div className="policy-metric">
          <span className="pm-label">Aderência dos advogados</span>
          <span className="pm-value good">87%</span>
        </div>
        <div className="policy-metric">
          <span className="pm-label">Acordos fechados (mês)</span>
          <span className="pm-value">214</span>
        </div>
        <div className="policy-metric">
          <span className="pm-label">Valor médio proposto</span>
          <span className="pm-value">R$ 6.420</span>
        </div>
        <div className="policy-metric">
          <span className="pm-label">Desvio de política</span>
          <span className="pm-value bad">12 casos</span>
        </div>
        <div className="mini-chart">
          {[40, 55, 48, 62, 58, 70, 66, 74, 80, 78, 85, 87].map((h, i) => (
            <div className="bar" key={i} style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
    </div>
  );
}

function DistributionCard() {
  return (
    <div className="rail-card">
      <div className="rail-card-header">
        <Icon name="scale" size={16} />
        <h3>Resultados · base histórica</h3>
        <span style={{fontFamily:'JetBrains Mono, monospace', fontSize:10, color:'var(--text-dim)'}}>60k casos</span>
      </div>
      <div className="rail-card-body">
        {RAW_STATS.map((s, i) => (
          <div key={i}>
            <div className="dist-row">
              <span className="lbl">{s.label}</span>
              <span className="val">{s.value}%</span>
            </div>
            <div className="dist-bar-outer">
              <div className={`dist-bar-inner ${s.kind}`} style={{ width: `${s.value}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AlertsCard() {
  return (
    <div className="rail-card">
      <div className="rail-card-header">
        <Icon name="bell" size={16} />
        <h3>Alertas operacionais</h3>
      </div>
      <div className="rail-card-body" style={{paddingTop: 4, paddingBottom: 4}}>
        {ALERTS.map((a, i) => (
          <div className="alert-item" key={i}>
            <span className={`alert-dot ${a.level}`} />
            <div className="alert-body">
              <div className="alert-title">{a.title}</div>
              <div className="alert-sub">{a.sub}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  TopBar, Sidebar, MacroStrip, CaseTable,
  AgentCard, PolicyCard, DistributionCard, AlertsCard,
});
