const { useState, useEffect, useRef, useCallback } = React;

/* ────────── ICONS (inline SVG, Lucide-style) ────────── */
const Icon = ({ name, size = 16, stroke = 1.8 }) => {
  const paths = {
    bell: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0',
    user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
    plus: 'M12 5v14 M5 12h14',
    msg: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
    dash: 'M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z',
    db: 'M21 5v14a9 3 0 0 1-18 0V5 M3 5a9 3 0 0 0 18 0 9 3 0 0 0-18 0 M3 12a9 3 0 0 0 18 0',
    gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
    logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9',
    search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.35-4.35',
    arrow: 'M5 12h14 M12 5l7 7-7 7',
    bot: 'M12 8V4H8 M2 14h2 M20 14h2 M15 13v2 M9 13v2 M5 18v-7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2z',
    trend: 'M23 6l-9.5 9.5-5-5L1 18 M17 6h6v6',
    shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
    file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6',
    scale: 'M16 16l3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1z M2 16l3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1z M7 21h10 M12 3v18 M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2',
    filter: 'M22 3H2l8 9.46V19l4 2v-8.54z',
    sliders: 'M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6',
  };
  const d = paths[name] || '';
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
      {d.split(' M').map((p, i) => <path key={i} d={(i ? 'M' : '') + p} />)}
    </svg>
  );
};

/* ────────── MOCK DATA ────────── */
const CASES = [
  { id: 1, number: '0801234-56.2024.8.10.0001', plaintiff: 'Maria das Graças Silva Pereira', type: 'Empréstimo Consignado', risk: 'Baixo', value: 'R$ 20.000,00', askedValue: 20000, recommendation: 'DEFESA', received: 'há 2h' },
  { id: 2, number: '0654321-09.2024.8.04.0001', plaintiff: 'José Raimundo Oliveira Costa', type: 'Empréstimo Consignado', risk: 'Alto', value: 'R$ 25.000,00', askedValue: 25000, recommendation: 'ACORDO', received: 'há 4h' },
  { id: 3, number: '0912445-78.2024.8.10.0003', plaintiff: 'Ana Luiza Barbosa Mendes', type: 'Empréstimo Consignado', risk: 'Médio', value: 'R$ 18.500,00', askedValue: 18500, recommendation: 'ACORDO', received: 'há 6h' },
  { id: 4, number: '0445789-12.2024.8.11.0002', plaintiff: 'Carlos Henrique Almeida', type: 'Empréstimo Consignado', risk: 'Baixo', value: 'R$ 12.300,00', askedValue: 12300, recommendation: 'DEFESA', received: 'há 8h' },
  { id: 5, number: '0334521-88.2024.8.10.0001', plaintiff: 'Juliana Ferreira Gomes', type: 'Empréstimo Consignado', risk: 'Alto', value: 'R$ 32.000,00', askedValue: 32000, recommendation: 'ACORDO', received: 'ontem' },
  { id: 6, number: '0778234-45.2024.8.04.0005', plaintiff: 'Roberto Carvalho Souza', type: 'Empréstimo Consignado', risk: 'Baixo', value: 'R$ 8.900,00', askedValue: 8900, recommendation: 'DEFESA', received: 'ontem' },
];

const MACRO = [
  { label: 'Novos processos (mês)', value: '4.872', sub: '+12% vs mês ant.', trend: 'up', accent: false },
  { label: 'Taxa de êxito', value: '69.6%', sub: '41.733 / 60.000', trend: 'up', accent: false },
  { label: 'Adesão à política', value: '87%', sub: '+3.2pp', trend: 'up', accent: true },
  { label: 'Ticket médio de condenação', value: 'R$ 9.340', sub: '−18% vs baseline', trend: 'down', accent: false },
];

const RAW_STATS = [
  { label: 'Improcedência', value: 46.6, kind: 'success' },
  { label: 'Extinção', value: 23.0, kind: 'success' },
  { label: 'Parcial Procedência', value: 20.4, kind: 'warning' },
  { label: 'Procedência', value: 9.6, kind: 'danger' },
  { label: 'Acordo', value: 0.5, kind: 'accent' },
];

const ALERTS = [
  { level: 'red', title: '3 casos de alto risco aguardando decisão', sub: 'SLA em <4h' },
  { level: 'yellow', title: 'Advogado externo fora da política em 2 casos', sub: 'Esc. Almeida & Partners' },
  { level: 'green', title: '86 acordos fechados nesta semana', sub: 'R$ 1.2M economizados' },
];

Object.assign(window, { Icon, CASES, MACRO, RAW_STATS, ALERTS });
